
from subprocess import Popen, PIPE
from tempfile import TemporaryFile

# texts = []
# codes = 0
#
script = 'echo 12345\nping 127.0.0.1'
codes = 0
with TemporaryFile('a+') as f:
    for line in script.splitlines():
        p = Popen(line, shell=True, stdout=f)
        code = p.wait()  # 阻塞等
        codes += code
    f.flush()
    f.seek(0)
    text = f.read()
print(codes)
print('-'*30)
print(text)


# from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
# import threading, time
# import random
#
# def test_func(s, key):
#     print('enter~~{} {}s key={}'.format(threading.current_thread(), s, key))
#     threading.Event().wait(s)
#     if key== 3:
#         raise Exception("{} failed~~~".format(key))
#     return 'ok {}'.format(threading.current_thread())
#
# futures= {}
#
# def run(fs):
#     print('~~~~~~~~~~~~~~')
#     while True:
#         time.sleep(1)
#         print('-'*30)
#         print(fs)
#         # 只要有一个任务没有完成就阻塞，完成一个，执行一次
#         # 如果内部有异常result()会将这个异常抛出
#         # 有异常也算执行完了complete
#         # fs为空也不阻塞
#         for future in as_completed(fs):
#             id= fs[future]
#             try:
#                 print(id, future.result())
#             except Exception as e:
#                 print(e)
#                 print(id, 'failed')
#
#
# threading.Thread(target=run, args=(futures,)).start()
#
# time.sleep(5)
#
# #executor = ThreadPoolExecutor(max_workers=3)
# with  ThreadPoolExecutor(max_workers=3) as executor:
#     for i in range(7):
#         futures[executor.submit(test_func, random.randint(1,8), i)] = i # 生成任务



