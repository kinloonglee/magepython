import web

if __name__ == '__main__':
    web.app.run()



